-- by Rick Black Labele
-- 02.05.2024

DensityMapHeightTypeLimitIncreaser = {};
addModEventListener(DensityMapHeightTypeLimitIncreaser);

function DensityMapHeightTypeLimitIncreaser:loadMap(name)
	DensityMapHeightManager.heightTypeNumChannels = 256.00000;
	print("New DensityMapHeightType Chain Limit: 256");
end;

function DensityMapHeightTypeLimitIncreaser:update(dt)
end
function DensityMapHeightTypeLimitIncreaser:deleteMap()
end;
function DensityMapHeightTypeLimitIncreaser:draw()
end;
function DensityMapHeightTypeLimitIncreaser:mouseEvent(posX, posY, isDown, isUp, button)
end;
function DensityMapHeightTypeLimitIncreaser:keyEvent(unicode, sym, modifier, isDown)
end;



