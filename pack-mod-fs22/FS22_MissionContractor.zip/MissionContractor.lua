MissionManager.getIsMissionWorkAllowed = Utils.overwrittenFunction(MissionManager.getIsMissionWorkAllowed, function (self, superFunc, farmId, x, z, workAreaType)
	local mission = self:getMissionAtWorldPosition(x, z)
    local farm = g_farmManager:getFarmById(farmId)

	if mission ~= nil and (mission.farmId == farmId or farm:getIsContractingFor(mission.farmId)) and (workAreaType == nil or mission.workAreaTypes[workAreaType]) then
		return true
	end

	return false
end
)