--Autor LSMT Modding Team Stefan Christian
--Version 1.0.1.0

PowerPack = {}

Player.MAX_PICKABLE_OBJECT_MASS = 9999
Player.MAX_PICKABLE_OBJECT_DISTANCE = 30
function PowerPack:loadMap(name)
end

function PowerPack:deleteMap()
end

function PowerPack:mouseEvent(posX, posY, isDown, isUp, button)
end

function PowerPack:keyEvent(unicode, sym, modifier, isDown)
end

function PowerPack:update(dt)
end

function PowerPack:draw(PowerPack)
end

function Vehicle:getCanBePickedUp(ply)
	local ownerId = self:getOwnerFarmId()
	if not ply.farmId or not ownerId then
		return self:getTotalMass() <= Player.MAX_PICKABLE_OBJECT_MASS
	end

    return ply.farmId == ownerId
end

function PowerPack:loadMap(name)
end;

function PowerPack:keyEvent(unicode, sym, modifier, isDown)
	local money = 1000000;
	if bitAND(modifier, Input.MOD_CTRL) > 0 and bitAND(modifier, Input.MOD_ALT) > 0 and Input.isKeyPressed(Input.KEY_0) then 
		if (g_currentMission.missionDynamicInfo.isMultiplayer == true) and (g_currentMission.player.farmId == FarmManager.SPECTATOR_FARM_ID) then
			print("PowerPack - Multiplayer game - Player has no Farm!");
		else
			g_currentMission:consoleCommandCheatMoney(money);
		end;
	end;
end;


function PowerPack:update(dt)
end;

function PowerPack:draw()
end;

function PowerPack:deleteMap()
end;

function PowerPack:mouseEvent(posX, posY, isDown, isUp, button)
end;
addModEventListener(PowerPack)